const loginBtn = document.querySelector('.loginbtn');
const email = document.querySelector('#email').value;
const password = document.querySelector('#password').value;
const chkemail = document.querySelector('.wrong_email');
const chkpass = document.querySelector('.wrong_password');

loginBtn.addEventListener('click', () => {
  if (email == ' ' && password == ' ') {
    chkemail.classList.add('show');
    chkpass.classList.add('show');
  } else {
    chkemail.classList.remove('show');
    chkpass.classList.remove('show');
  }
});
